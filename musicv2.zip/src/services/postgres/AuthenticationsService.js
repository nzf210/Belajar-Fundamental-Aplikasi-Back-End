const { Pool } = require('pg');
const InvariantError = require('../../exceptions/InvariantError');

class AuthenticationsService {
    constructor() {
        this.pool = new Pool();
    }

    async addRefreshToken(token) {
        const query = {
            text: 'INSERT INTO token VALUES($1)',
            values: [token],
        };

        await this.pool.query(query);
    }

    async verifyRefreshToken(token) {
        const query = {
            text: 'SELECT token FROM token WHERE token = $1',
            values: [token],
        };

        const { rowCount } = await this.pool.query(query);
        if (!rowCount) {
            throw new InvariantError('Refresh token tidak valid');
        }
    }

    async deleteRefreshToken(token) {
        const query = {
            text: 'DELETE FROM token WHERE token = $1',
            values: [token],
        };
        await this.pool.query(query);
    }
}

module.exports = { AuthenticationsService };